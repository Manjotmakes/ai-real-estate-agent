"use client"

import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { Toaster } from "react-hot-toast"
import { useState, useEffect } from "react"
import Sidebar from "./components/Sidebar"
import Header from "./components/Header"
import LandingPage from "./pages/LandingPage"
import Dashboard from "./pages/Dashboard"
import PropertyDetails from "./pages/PropertyDetails"
import UploadPDF from "./pages/UploadPDF"
import "./App.css"

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
})

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem("darkMode")
    return saved ? JSON.parse(saved) : false
  })

  useEffect(() => {
    localStorage.setItem("darkMode", JSON.stringify(darkMode))
    document.documentElement.setAttribute("data-theme", darkMode ? "dark" : "light")
  }, [darkMode])

  const toggleDarkMode = () => {
    setDarkMode(!darkMode)
  }

  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <Routes>
          <Route path="/" element={<LandingPage darkMode={darkMode} toggleDarkMode={toggleDarkMode} />} />
          <Route
            path="/*"
            element={
              <div className="flex h-screen bg-gradient-primary overflow-hidden">
                <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} darkMode={darkMode} />
                <div className="flex-1 flex flex-col overflow-hidden">
                  <Header
                    onMenuClick={() => setSidebarOpen(true)}
                    darkMode={darkMode}
                    toggleDarkMode={toggleDarkMode}
                  />
                  <main className="flex-1 overflow-auto main-content">
                    <Routes>
                      <Route path="/dashboard" element={<Dashboard />} />
                      <Route path="/upload" element={<UploadPDF />} />
                      <Route path="/property/:id" element={<PropertyDetails />} />
                    </Routes>
                  </main>
                </div>
              </div>
            }
          />
        </Routes>
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: darkMode ? "rgba(30, 41, 59, 0.95)" : "rgba(255, 255, 255, 0.95)",
              color: darkMode ? "#f8fafc" : "#0f172a",
              backdropFilter: "blur(10px)",
              border: `1px solid ${darkMode ? "rgba(255, 255, 255, 0.1)" : "rgba(0, 0, 0, 0.1)"}`,
              borderRadius: "12px",
            },
          }}
        />
      </Router>
    </QueryClientProvider>
  )
}

export default App
