"use client"

import { Menu, User, Sun, Moon } from "lucide-react"

interface HeaderProps {
  onMenuClick: () => void
  darkMode: boolean
  toggleDarkMode: () => void
}

const Header = ({ onMenuClick, darkMode, toggleDarkMode }: HeaderProps) => {
  return (
    <header className="glass border-b border-gray-200 dark:border-gray-700 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={onMenuClick}
            className="lg:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-secondary hover:text-primary transition-colors"
          >
            <Menu className="h-6 w-6" />
          </button>

          <div>
            <h2 className="text-xl font-semibold text-primary">Property Management</h2>
            <p className="text-sm text-tertiary">Manage your real estate portfolio</p>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {/* Dark Mode Toggle */}
          <button
            onClick={toggleDarkMode}
            className={`theme-toggle ${darkMode ? "active" : ""}`}
            title={darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
          >
            <div className="theme-toggle-slider">
              {darkMode ? <Moon className="h-3 w-3 text-gray-600" /> : <Sun className="h-3 w-3 text-yellow-500" />}
            </div>
          </button>

          <div className="flex items-center space-x-3 pl-4 border-l border-gray-200 dark:border-gray-700">
            <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center">
              <User className="h-5 w-5 text-white" />
            </div>
            <div className="hidden md:block">
              <p className="text-primary font-medium text-sm">Admin User</p>
              <p className="text-tertiary text-xs">admin@realestate.ai</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header
