"use client"

import { Link, useLocation } from "react-router-dom"
import { Home, Upload, Building2, BarChart3, Settings, HelpCircle, X, Sparkles, Mail, TrendingUp } from "lucide-react"

interface SidebarProps {
  isOpen: boolean
  onClose: () => void
}

const Sidebar = ({ isOpen, onClose }: SidebarProps) => {
  const location = useLocation()

  const navigation = [
    { name: "Dashboard", href: "/dashboard", icon: Home },
    { name: "Upload PDF", href: "/upload", icon: Upload },
    { name: "Properties", href: "/properties", icon: Building2 },
    { name: "Analytics", href: "/analytics", icon: BarChart3 },
    { name: "Email Center", href: "/emails", icon: Mail },
    { name: "Reports", href: "/reports", icon: TrendingUp },
  ]

  const secondaryNavigation = [
    { name: "Settings", href: "/settings", icon: Settings },
    { name: "Help & Support", href: "/help", icon: HelpCircle },
  ]

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && <div className="fixed inset-0 z-40 bg-black bg-opacity-50 lg:hidden" onClick={onClose} />}

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-50 w-72 sidebar transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0 ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center justify-between p-6 border-b border-white/10">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gradient-primary rounded-xl">
                <Building2 className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-white font-bold text-lg">RealEstate AI</h1>
                <p className="text-gray-400 text-xs">Property Intelligence</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="lg:hidden p-2 rounded-lg hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 py-6 space-y-2">
            <div className="mb-6">
              <h3 className="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-3">Main Menu</h3>
              {navigation.map((item) => {
                const isActive = location.pathname === item.href
                return (
                  <Link
                    key={item.name}
                    to={item.href}
                    className={`flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                      isActive
                        ? "bg-gradient-primary text-white shadow-lg"
                        : "text-gray-300 hover:bg-white/10 hover:text-white"
                    }`}
                  >
                    <item.icon className="h-5 w-5" />
                    <span className="font-medium">{item.name}</span>
                    {isActive && (
                      <div className="ml-auto">
                        <Sparkles className="h-4 w-4" />
                      </div>
                    )}
                  </Link>
                )
              })}
            </div>

            <div>
              <h3 className="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-3">Other</h3>
              {secondaryNavigation.map((item) => {
                const isActive = location.pathname === item.href
                return (
                  <Link
                    key={item.name}
                    to={item.href}
                    className={`flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                      isActive ? "bg-gradient-primary text-white" : "text-gray-300 hover:bg-white/10 hover:text-white"
                    }`}
                  >
                    <item.icon className="h-5 w-5" />
                    <span className="font-medium">{item.name}</span>
                  </Link>
                )
              })}
            </div>
          </nav>

          {/* User Profile */}
          <div className="p-4 border-t border-white/10">
            <div className="flex items-center space-x-3 p-3 rounded-xl bg-white/5">
              <div className="w-10 h-10 bg-gradient-secondary rounded-full flex items-center justify-center">
                <span className="text-white font-semibold text-sm">AI</span>
              </div>
              <div className="flex-1">
                <p className="text-white font-medium text-sm">AI Assistant</p>
                <p className="text-gray-400 text-xs">Always Online</p>
              </div>
              <div className="w-3 h-3 bg-green-400 rounded-full status-online"></div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default Sidebar
