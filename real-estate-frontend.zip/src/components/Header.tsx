"use client"

import { Menu, Bell, Search, User, Settings } from "lucide-react"
import { useState } from "react"

interface HeaderProps {
  onMenuClick: () => void
}

const Header = ({ onMenuClick }: HeaderProps) => {
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <header className="glass border-b border-white/20 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={onMenuClick}
            className="lg:hidden p-2 rounded-lg hover:bg-white/10 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <Menu className="h-6 w-6" />
          </button>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search properties, contacts, or reports..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 w-80 bg-white/50 border border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent placeholder-gray-500"
            />
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <button className="relative p-2 rounded-lg hover:bg-white/10 text-gray-600 hover:text-gray-900 transition-colors">
            <Bell className="h-6 w-6" />
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
              3
            </span>
          </button>

          <button className="p-2 rounded-lg hover:bg-white/10 text-gray-600 hover:text-gray-900 transition-colors">
            <Settings className="h-6 w-6" />
          </button>

          <div className="flex items-center space-x-3 pl-4 border-l border-white/20">
            <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center">
              <User className="h-5 w-5 text-white" />
            </div>
            <div className="hidden md:block">
              <p className="text-gray-900 font-medium text-sm">Admin User</p>
              <p className="text-gray-500 text-xs">admin@realestate.ai</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header
